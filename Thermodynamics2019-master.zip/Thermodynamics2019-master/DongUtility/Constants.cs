﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DongUtility
{
    static public class Constants
    {
        public const double SpeedOfLight = 299792458;

        public const byte MaxByte = 255;
    }
}
