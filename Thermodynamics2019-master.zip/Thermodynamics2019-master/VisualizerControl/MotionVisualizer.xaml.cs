﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;
using System.Windows;
using System.Windows.Controls;

namespace VisualizerControl
{
    /// <summary>
    /// A visualizer that can move the particles automatically with a fixed time increment
    /// </summary>
    public partial class MotionVisualizer : UserControl
    {
        private Visualizer visualizer;
        private double time = 0;
        private double timeIncrement = .01;
        public double TimeIncrement
        {
            get => timeIncrement;
            set
            {
                timeIncrement = value;
                TimeIncrementSlider.Text = timeIncrement.ToString();
            }
        } // in seconds
        private double timeScale = 1;
        public double TimeScale
        {
            get => TimeScale;
            set
            {
                timeScale = value;
                TimeScaleSlider.Text = timeScale.ToString();
            }
        }

        private bool autoCamera = false;
        public bool AutoCamera
        {
            get => autoCamera;
            set
            {
                autoCamera = value;
                AutoCameraCheck.IsChecked = value;
            }
        }

        // To keep time
        private Stopwatch timer = new Stopwatch();

        private IVisualization engine;

        // For multithreading communications
        private BufferBlock<PackagedCommands> turnBuffer = new BufferBlock<PackagedCommands>();
        private Task engineTask;
        private Task visualizerTask;

        public string BackgroundFile
        {
            set
            {
                visualizer.BackgroundFile = value;
            }
        }

        public MotionVisualizer(IVisualization engine)
        {
            InitializeComponent();

            this.engine = engine;

            visualizer = new Visualizer();
            VisualizerSpot.Content = visualizer;

            // Do initial setup
            engine.Initialization().ProcessAll(visualizer);
        }

        /// <summary>
        /// Add a new element to the top menu bar
        /// </summary>
        public void AddControl(UIElement control)
        {
            ButtonBar.Children.Add(control);
        }

        /// <summary>
        /// Whether the 3D should be updating while the engine calculates
        /// Can be turned off to speed up graph generation time
        /// </summary>
        public bool Display { get; set; } = true;

        /// <summary>
        /// Gets and sets whether the simulation is running
        /// </summary>
        public bool IsRunning
        {
            get
            {
                return timer.IsRunning;
            }
            set
            {
                if (value)
                    timer.Start();
                else
                    timer.Stop();
            }
        }

        private void Start_Button_Click(object sender, RoutedEventArgs e)
        {
            if (IsRunning)
            {
                Start_Button.Content = "Resume";
                IsRunning = false;
            }
            else
            {
                Start_Button.Content = "Pause";
                IsRunning = true;

                if (engineTask == null && visualizerTask == null)
                {
                    StartAll();
                }
            }
        }

        /// <summary>
        /// Used to wait to see if drawing is done
        /// </summary>
        private bool doneDrawing = true;

        /// <summary>
        /// Includes all the information needed by the visualizer piece that the engine will pass it
        /// </summary>
        private class PackagedCommands
        {
            public PackagedCommands(VisualizerCommandSet commands, double time)
            {
                Commands = commands;
                Time = time;
            }

            /// <summary>
            /// The command set
            /// </summary>
            public VisualizerCommandSet Commands { get; set; }
            /// <summary>
            /// The time of the commands
            /// </summary>
            public double Time { get; set; }
        }

        /// <summary>
        /// Start or continue the engine running
        /// </summary>
        private void RunEngine()
        {
            while (engine.Continue)
            {
                if (IsRunning)
                {
                    // This is probably not the best way to do it
                    while (!doneDrawing)
                    { }
                    double newTime = engine.Time + TimeIncrement;
                    // Create package of commands
                    var package = new PackagedCommands(engine.Tick(newTime), newTime);
                    // Send to the buffer
                    turnBuffer.Post(package);

                    // Wait until drawing is done
                    doneDrawing = false;
                }
            }

            turnBuffer.Complete();
        }

        /// <summary>
        /// Updates visualization
        /// </summary>
        private async Task UpdateVisualAsync()
        {
            while (await turnBuffer.OutputAvailableAsync())
            {
                var turn = turnBuffer.Receive();
                if (Display)
                {
                    // Process commands
                    turn.Commands.ProcessAll(visualizer);
                    // Redraw screen
                    visualizer.InvalidateVisual();
                }
                // Update time display
                time = turn.Time;
                TimeValue.Text = Math.Round(time, 5).ToString();

                if (autoCamera)
                    visualizer.AdjustCamera();

                // Raise event for graphs
                OnUpdateTriggered(new EventArgs());

                // Check if delay is needed
                var timeDiff = turn.Time - timer.Elapsed.TotalSeconds * timeScale;
                if (timeDiff > 0)
                {
                    // This delays it so the clocks will line up
                    await Task.Delay((int)(timeDiff * 1000)); // Convert to milliseconds
                }

                // Signal that drawing is done
                doneDrawing = true;
            }
        }

        /// <summary>
        /// Starts all tasks
        /// </summary>
        private void StartAll()
        {
            visualizerTask = UpdateVisualAsync();
            engineTask = Task.Run(() => RunEngine());
        }

        /// <summary>
        /// An update event, mainly for graphs
        /// </summary>
        public event EventHandler UpdateTriggered;

        protected virtual void OnUpdateTriggered(EventArgs e)
        {
            UpdateTriggered?.Invoke(this, e);
        }

        private void TimeIncrementSlider_TextChanged(object sender, TextChangedEventArgs e)
        {
            ChangeSlider(TimeIncrementSlider, ref timeIncrement);
        }

        private void ChangeSlider(TextBox textBox, ref double result)
        {
            if (double.TryParse(textBox.Text, out double newNum))
                result = newNum;
        }

        private void AutoCameraCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (AutoCameraCheck.IsChecked != null)
            {
                autoCamera = (bool)AutoCameraCheck.IsChecked;
                if (!timer.IsRunning && autoCamera)
                    visualizer.AdjustCamera();
            }
        }

        private void TimeScaleSlider_TextChanged(object sender, TextChangedEventArgs e)
        {
            ChangeSlider(TimeScaleSlider, ref timeScale);
        }

        private void DisplayCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (DisplayCheck.IsChecked != null)
            {
                Display = (bool)DisplayCheck.IsChecked;
            }
        }
    }
}
