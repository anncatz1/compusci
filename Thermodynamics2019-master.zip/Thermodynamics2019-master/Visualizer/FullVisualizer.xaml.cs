﻿using DongUtility;
using GraphControl;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VisualizerControl;

namespace Visualizer
{
    /// <summary>
    /// A kinematics visualizer with graphs
    /// </summary>
    public partial class FullVisualizer : Window
    {
        public MotionVisualizer Visualizer { get; }

        private CheckBox display3D = new CheckBox();

        /// <summary>
        /// The current background
        /// </summary>
        public string BackgroundFile
        {
            set
            {
                Visualizer.BackgroundFile = value;
            }
        }

        public FullVisualizer(IVisualization engine)
        {
            InitializeComponent();

            Visualizer = new MotionVisualizer(engine);
            Viewport.Content = Visualizer;

            // Connect the graph update event
            Visualizer.UpdateTriggered += UpdateTrigger;

            // Add a save button
            var saveButton = new Button
            {
                Content = "Save",
                Padding = new Thickness(5)
            };
            saveButton.Click += Save_Button_Click;
            Visualizer.AddControl(saveButton);

            // Add a screenshot button
            var screenshotButton = new Button
            {
                Content = "Screenshot",
                Padding = new Thickness(5)
            };
            screenshotButton.Click += Screenshot_Button_Click;
            Visualizer.AddControl(screenshotButton);
        }

        public delegate Vector3D VectorFunc();

        public void AddGraph(string name, Timeline.GetValue funcX, Timeline.GetValue funcY, string xTitle, string yTitle, Color color)
        {
            var graphU = new GraphUnderlying(xTitle, yTitle);
            graphU.AddTimeline(new Timeline(name, funcX, funcY, color));
            Graphs.AddGraph(new Graph(graphU));
        }

        /// <summary>
        /// A shortcut function to add a 3D graph
        /// </summary>
        /// <param name="name">The name of the variable</param>
        /// <param name="funcX">The function to call for the x axis (probably time)</param>
        /// <param name="funcY">The function to call for the y axis - must return a Vector3D</param>
        /// <param name="xTitle">The x-axis title</param>
        /// <param name="yTitle">The y-axis title</param>
        public void Add3DGraph(string name, Timeline.GetValue funcX, VectorFunc funcY, string xTitle, string yTitle)
        {
            GraphUnderlying graphU = new GraphUnderlying(xTitle, yTitle);
            graphU.AddTimeline(new Timeline("x " + name, funcX, (() => funcY().X), Colors.Red));
            graphU.AddTimeline(new Timeline("y " + name, funcX, (() => funcY().Y), Colors.Green));
            graphU.AddTimeline(new Timeline("z " + name, funcX, (() => funcY().Z), Colors.Blue));
            Graphs.AddGraph(new Graph(graphU));
        }

        private void UpdateTrigger(object sender, EventArgs e)
        {
            Graphs.Update();
        }
        
        private void Save_Button_Click(object sender, RoutedEventArgs e)
        {
            bool needToRestart = false;
            if (Visualizer.IsRunning)
            {
                Visualizer.IsRunning = false;
                needToRestart = true;
            }
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog
            {
                FileName = "Screenshot",
                DefaultExt = ".jpg"
            };

            if (dlg.ShowDialog() == true)
            {
                string filename = dlg.FileName;

                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(MakeScreenshot()));
                using (Stream fileStream = File.Create(filename))
                {
                    encoder.Save(fileStream);
                }
            }

            if (needToRestart)
            {
                Visualizer.IsRunning = true;
            }
        }

        private void Screenshot_Button_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetImage(MakeScreenshot());
        }

        private RenderTargetBitmap MakeScreenshot()
        {
            RenderTargetBitmap bitmap = new RenderTargetBitmap((int)ActualWidth, (int)ActualHeight, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(this);
            return bitmap;
        }
    }
}
