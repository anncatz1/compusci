﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisualizerControl;
using Projectile_Motion;
using System.IO;
using Utilities;

namespace Visualizer
{
    public class EngineAdapter : IEngine
    {
        private World engine = new World(0, new Vector(0,0,-9.8));

        public EngineAdapter(World engine)
        {
            this.engine = engine;
        }

        bool IEngine.Tick(double newTime)
        {
            double deltaTime = newTime - engine.Time;
            engine.Time += deltaTime;
            double totalTime = 10;
            engine.Tick(deltaTime);
            if (totalTime == newTime)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public IList<IProjectile> GetProjectiles()
        {
            List<IProjectile> projectiles = new List<IProjectile>();
            //List<Projectile> projects = engine.projectiles;
            foreach (var projectile in engine.projectiles)
            {
                ProjectileAdapter proj = new ProjectileAdapter(projectile);
                projectiles.Add(proj);
            }
            return projectiles;
        }
    }
}
