﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphControl
{
    public struct Range
    { 
        public struct RangePair
        {
            public RangePair(double min, double max)
            {
                Min = min;
                Max = max;
            }

            public double Min;
            public double Max;
            public double Range => Max - Min;

            public void SetMinMax(double val)
            {
                if (val < Min)
                    Min = val;
                if (val > Max)
                    Max = val;
            }

            public void AdjustRange(RangePair pair)
            {
                AdjustRange(pair.Min, pair.Max);
            }

            public void AdjustRange(double min, double max)
            {
                if (min < Min)
                    Min = min;
                if (max > Max)
                    Max = max;
            }
        }

        static public Range DefaultRange()
        {
            return new Range(Double.MaxValue, Double.MaxValue, Double.MinValue, Double.MinValue);
        }

        public Range(double minx, double miny, double maxx, double maxy)
        {
            X = new RangePair(minx, maxx);
            Y = new RangePair(miny, maxy);
        }

        public RangePair X;
        public RangePair Y;

        public double Width => X.Range;
        public double Height => Y.Range;

        public void SetMinMax(double xVal, double yVal)
        {
            X.SetMinMax(xVal);
            Y.SetMinMax(yVal);
        }

        public void AdjustRange(Range other)
        {
            X.AdjustRange(other.X);
            Y.AdjustRange(other.Y);
        }

    }
}
