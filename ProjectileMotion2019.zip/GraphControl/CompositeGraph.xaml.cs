﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GraphControl
{
    /// <summary>
    /// Interaction logic for CompositeGraph.xaml
    /// </summary>
    public partial class CompositeGraph : UserControl, IUpdating
    {
        public List<IUpdating> graphs = new List<IUpdating>();

        public CompositeGraph()
        {
            InitializeComponent();
        }

        public IUpdating GetGraph(int index)
        {
            return graphs[index];
        }

        public int GetNGraphs()
        {
            return graphs.Count;
        }

        public void AddSingleGraph(string name, Timeline.GetValue funcX, Timeline.GetValue funcY, Color color, string xTitle, string yTitle)
        {
            GraphUnderlying graphU = new GraphUnderlying(xTitle, yTitle);
            graphU.AddTimeline(new Timeline(name, funcX, funcY, color));
            AddGraph(new Graph(graphU));
        }

        public void AddHist(Histogram.ListFunc func, int nBins, Color color, string xTitle)
        {
            AddToGraphList(new Graph(new Histogram(func, nBins, color, xTitle)));
        }

        public void AddGraph(Graph graph)
        {
            AddToGraphList(graph);
        }

        public void AddText(string name, Timeline.GetValue func, Color color)
        {
            AddText(name, () => func().ToString(), color);
        }

        public void AddText(string name, UpdatingText.GetText func, Color color)
        {
            var bl = new UpdatingText
            {
                Title = name,
                Function = func,
                Color = color
            };

            AddToGraphList(bl);
        }

        private void AddToGraphList(UserControl control)
        {
            GraphPanel.RowDefinitions.Add(new RowDefinition());
            GraphPanel.Children.Add(control);
            Grid.SetRow(control, GraphPanel.RowDefinitions.Count - 1);

            if (control is IUpdating)
            {
                graphs.Add((IUpdating)control);
            }
        }

        public void Update()
        {
            foreach (var graph in graphs)
            {
                graph.Update();
            }
        }

        public void Clear()
        {
            graphs.Clear();
            GraphPanel.Children.Clear();
            GraphPanel.RowDefinitions.Clear();
        }
    }
}
