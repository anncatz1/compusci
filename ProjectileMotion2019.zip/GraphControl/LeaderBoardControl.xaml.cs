﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GraphControl;
using System.Media;

namespace GraphControl
{
    /// <summary>
    /// Interaction logic for LeaderBoardControl.xaml
    /// </summary>
    public partial class LeaderBoardControl : UserControl, IUpdating
    {
        public LeaderBoardControl()
        {
            InitializeComponent();
        }

        private List<LeaderBar> entries = new List<LeaderBar>();

        public bool HasEntry(string name) => entries.Any(x => x.NameOfBar == name);

        public void AddEntry(string name, Color color, LeaderBar.Status function, LeaderBar.StringStatus stringFunction = null)
        {
            var newBar = new LeaderBar
            {
                NameOfBar = name,
                Color = color,
                UpdateFunction = function,
                StringUpdateFunction = stringFunction
            };

            entries.Add(newBar);

            TheGrid.Rows = entries.Count;
            TheGrid.Children.Add(newBar);

            Update();
        }

        public void Update()
        {
            double max = 0;

            foreach (var bar in entries)
            {
                bar.Update();
                if (bar.NumberOnRight > max)
                {
                    max = bar.NumberOnRight;
                }
            }

            foreach (var bar in entries)
            {
                bar.BarLength = (double)bar.NumberOnRight / max;
            }

            entries.Sort(new Sorter());
            TheGrid.Children.Clear();
            foreach (var entry in entries)
            {
                TheGrid.Children.Add(entry);
            }
        }

        private class Sorter : IComparer<LeaderBar>
        {
            public int Compare(LeaderBar x, LeaderBar y)
            {
                return -(x.NumberOnRight.CompareTo(y.NumberOnRight));
            }
        }
    }
}
