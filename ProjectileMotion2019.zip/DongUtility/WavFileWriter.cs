﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace DongUtility
{
    public class WavFileWriter
    {
        public ushort NumChannels { get; set; } = 1;
        public uint SampleRate { get; set; } = 44100;
        public const ushort BitsPerSample = 32;

        public double Amplification { get; set; } = 1;

        private List<int> samples = new List<int>();

        private const int maxVal = 2147483647;
        private const int minVal = -2147483648;

        public void AddSamples(IEnumerable<double> samples)
        {
            NormalizeAndAdd(samples);
        }

        public void CreateInterpolatedSamples(IEnumerable<Tuple<double, double>> original)
        {
            var templist = new List<double>();

            double timePerSample = 1.0 / SampleRate;

            var oldval = new Tuple<double, double>(0, 0);
            double runningTotal = 0;
            int nSamples = 0;

            foreach (var pair in original)
            {
                double timeDiff = pair.Item1 - oldval.Item1;

                if (timeDiff <= 0)
                {
                    throw new ArgumentException("Input to CreateInterpolatedSamples() is not time-ordered");
                }

                if (timeDiff > timePerSample)
                {
                    if (runningTotal > 0)
                    {
                        templist.Add(runningTotal / nSamples);
                        runningTotal = 0;
                        nSamples = 0;
                    }
                    else
                    {
                        Interpolate(oldval, pair, ref templist);
                    }
                    oldval = pair;
                }
                else if (timeDiff < timePerSample)
                {
                    runningTotal += pair.Item2;
                    ++nSamples;
                }

            }

            NormalizeAndAdd(templist);
        }

        private void Interpolate(Tuple<double, double> oldPair, Tuple<double, double> newPair, ref List<double> list)
        {
            double timeDiff = newPair.Item1 - oldPair.Item1;
            int nSteps = (int)Math.Round(timeDiff * SampleRate);

            double eachStep = (newPair.Item2 - oldPair.Item2) / nSteps;

            double current = oldPair.Item2;
            for (int i = 0; i < nSteps; ++i)
            {
                list.Add(current += eachStep);
            }
        }

        private void NormalizeAndAdd(IEnumerable<double> samples)
        {
            double max = 0;

            foreach (var sample in samples)
            {
                if (Math.Abs(sample) > max)
                    max = Math.Abs(sample);
            }

            foreach (var sample in samples)
            {
                int pitch = (int)(sample * Amplification / max * maxVal);

                if (pitch > maxVal)
                    pitch = maxVal;
                if (pitch < minVal)
                    pitch = minVal;
                this.samples.Add(pitch);
            }
        }

        private int TotalFileSize()
        {
            return (samples.Count * BitsPerSample / 8);
        }

        public void WriteFile(string filename)
        {
            using (FileStream file = new FileStream(filename, FileMode.Create))
            {
                BinaryWriter wr = new BinaryWriter(file);

                wr.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
                wr.Write(36 + TotalFileSize());
                wr.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));
                wr.Write((uint)16);
                wr.Write((ushort)1);
                wr.Write(NumChannels);
                wr.Write(SampleRate);
                ushort totalBytesPerSample = (ushort)(NumChannels * BitsPerSample / 8);
                uint byteRate = totalBytesPerSample * SampleRate;
                wr.Write(byteRate);
                wr.Write(totalBytesPerSample);
                wr.Write(BitsPerSample);

                wr.Write(System.Text.Encoding.ASCII.GetBytes("data"));
                wr.Write((uint)TotalFileSize());

                foreach (var sample in samples)
                {
                    wr.Write(sample);
                }
            }
        }
    }
}
