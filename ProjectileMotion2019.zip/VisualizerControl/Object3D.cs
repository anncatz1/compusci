﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using VisualizerControl.Shapes;

namespace VisualizerControl
{
    abstract public class Object3D
    {
        private Shape3D shape;

        public GeometryModel3D GeoModel { get; private set; }

        private TranslateTransform3D translation = new TranslateTransform3D();
        private ScaleTransform3D scale = new ScaleTransform3D();
        private AxisAngleRotation3D thetaRotation = new AxisAngleRotation3D();
        private AxisAngleRotation3D phiRotation = new AxisAngleRotation3D(new Vector3D(0, 0, 1), 0);
        private RotateTransform3D rotation;

        static private Dictionary<Color, Brush> brushes = new Dictionary<Color, Brush>();
        static private Dictionary<Color, DiffuseMaterial> diffMaterials = new Dictionary<Color, DiffuseMaterial>();
        static private Dictionary<Color, SpecularMaterial> specMaterials = new Dictionary<Color, SpecularMaterial>();

        public Object3D(Shape3D shape, Material material)
        {
            this.shape = shape;
            rotation = new RotateTransform3D(phiRotation);
            rotation = new RotateTransform3D(thetaRotation);

            // Create transformation
            var transGroup = new Transform3DGroup();
            transGroup.Children.Add(scale);
            transGroup.Children.Add(rotation);
            transGroup.Children.Add(translation);

            // Create geometry model
            GeoModel = new GeometryModel3D(shape.Mesh, material)
            {
                Transform = transGroup
            };
        }

        public Vector3D Position
        {
            get
            {
                return new Vector3D(translation.OffsetX, translation.OffsetY, translation.OffsetZ);
            }
            set
            {
                translation.OffsetX = value.X;
                translation.OffsetY = value.Y;
                translation.OffsetZ = value.Z;
            }
        }

        public Vector3D Scale
        {
            get
            {
                return new Vector3D(scale.ScaleX, scale.ScaleY, scale.ScaleZ);
            }
            set
            {
                scale.ScaleX = value.X;
                scale.ScaleY = value.Y;
                scale.ScaleZ = value.Z;
            }
        }

        public void ScaleEvenly(double scale)
        {
            Scale = new Vector3D(scale, scale, scale);
        }

        public double AzimuthalAngle
        {
            get
            {
                return phiRotation.Angle;
            }
            set
            {
                phiRotation.Angle = UtilityFunctions.RadiansToDegrees(value);
                thetaRotation.Axis = new Vector3D(-Math.Sin(value), Math.Cos(value), 0);
            }
        }

        public double PolarAngle
        {
            get
            {
                return thetaRotation.Angle;
            }
            set
            {
                thetaRotation.Angle = UtilityFunctions.RadiansToDegrees(value);
            }
        }

        public Object3D(Shape3D shape, Color color, bool specular = false) :
            this(shape, GetMaterial(color, specular))
        {
        }

        protected void ChangeColor(Color color, bool specular = false)
        {
            var material = GetMaterial(color, specular);
            GeoModel.Material = material;
        }

        private const double specularCoefficient = 1;

        static private Material GetMaterial(Color color, bool specular = false)
        {
            if (!brushes.ContainsKey(color))
            {
                var newBrush = new SolidColorBrush(color);
                newBrush.Freeze();
                brushes[color] = newBrush;
            }
            var brush = brushes[color];

            if (specular)
            {
                if (!specMaterials.ContainsKey(color))
                {
                    var newMaterial = new SpecularMaterial(brush, specularCoefficient);
                    newMaterial.Freeze();
                    specMaterials[color] = newMaterial;
                }
                return specMaterials[color];
            }
            else
            {
                if (!diffMaterials.ContainsKey(color))
                {
                    var newMaterial = new DiffuseMaterial(brush);
                    newMaterial.Freeze();
                    diffMaterials[color] = newMaterial;
                }
                return diffMaterials[color];
            }
        }

        abstract public void Update();
    }
}
