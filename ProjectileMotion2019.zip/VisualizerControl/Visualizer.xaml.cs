﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Input;
using VisualizerControl.Visualizations;
using DongUtility;

namespace VisualizerControl
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Visualizer : UserControl
    {
        private IVisualization visualization;

        public delegate Vector3D VectorFunc();

        private List<Object3D> objects = new List<Object3D>();

        public bool Tick(double time)
        {
            return visualization.Tick(time);
        }

        public Visualizer(IVisualization visualization)
        {
            this.visualization = visualization;
            InitializeComponent();
            visualization.SetVisualizer(this);
            visualization.Initialize();
            foreach (var part in visualization.GetObjects())
            {
                objects.Add(part);
                Group.Children.Add(part.GeoModel);
            }
        }

        public void AddParticle(Object3D part)
        {
            objects.Add(part);
            Group.Children.Add(part.GeoModel);
        }

        public void RemoveParticle(Object3D part)
        {
            if (objects.Contains(part))
            {
                objects.Remove(part);
            }
            else
            {
                throw new KeyNotFoundException("RemoveParticle: object not found!");
            }
            Group.Children.Remove(part.GeoModel);
        }

        public void AdjustCamera()
        {
            if (objects.Count == 0)
            {
                return;
            }
            else if (objects.Count == 1)
            {
                double offset = 10; // Because why not
                Vector3D direction = new Vector3D(1, 1, 1);
                direction.Normalize();
                Vector3D pos = objects[0].Position + offset * direction;
                Camera.Position = new Point3D(pos.X, pos.Y, pos.Z);
                Camera.LookDirection = objects[0].Position - pos;
            }
            else
            {
                Vector3D centerOfParticles = Center();
                Camera.Position = new Point3D(centerOfParticles.X, centerOfParticles.Y, centerOfParticles.Z);
                Camera.LookDirection = (-centerOfParticles) / centerOfParticles.Length;

                double maxDistance = 0;

                foreach (var proj in objects)
                {
                    double bestDistance = CamDistance(proj.Position);
                    if (bestDistance > maxDistance)
                        maxDistance = bestDistance;
                }

                Vector3D newPos = maxDistance / centerOfParticles.Length * centerOfParticles;
                Camera.Position = new Point3D(newPos.X, newPos.Y, newPos.Z);
            }
        }

        private Vector3D Center()
        {
            Vector3D response = new Vector3D(0, 0, 0);

            foreach (var proj in objects)
            {
                response += proj.Position;
            }
            return response /= objects.Count;
        }

        private bool IsInCamera(Vector3D vec)
        {
            Vector3D fromCamera = vec - new Vector3D(Camera.Position.X, Camera.Position.Y, Camera.Position.Z);
            fromCamera.Normalize();
            Vector3D lookDirection = Camera.LookDirection;
            lookDirection.Normalize();
            double dot = Vector3D.DotProduct(fromCamera, lookDirection);
            double angleBetween = Math.Acos(dot);
            return angleBetween < Camera.FieldOfView / 2;
        }

        private double CamDistance(Vector3D vec)
        {
            double angle = Camera.FieldOfView / 2;

            Vector3D camPosition = new Vector3D(Camera.Position.X, Camera.Position.Y, Camera.Position.Z);
            Vector3D camDirection = Camera.LookDirection - camPosition;
            double distance = DistanceLineToPoint(camPosition, camDirection, vec);

            double distanceAlongAxis = distance / Math.Tan(angle);
            double pointDistance = Vector3D.DotProduct(vec, camPosition) / camPosition.Length;
            return distanceAlongAxis + pointDistance;
        }

        // From Wolfram Mathworld,
        // http://mathworld.wolfram.com/Point-LineDistance3-Dimensional.html
        private double DistanceLineToPoint(Vector3D lineVec1, Vector3D lineVec2, Vector3D point)
        {
            Vector3D x0x1 = point - lineVec1;
            Vector3D x0x2 = point - lineVec2;
            Vector3D x2x1 = lineVec2 - lineVec1;

            Vector3D numVec = Vector3D.CrossProduct(x0x1, x0x2);
            Vector3D denVec = x2x1;
            return numVec.Length / denVec.Length;
        }

        private Point previousMouse;
        private Transform3D currentTransform = MatrixTransform3D.Identity;

        private void MyViewport_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            previousMouse = e.GetPosition(null);
        }

        private void MyViewport_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            currentTransform = Camera.Transform;
        }

        private void MyViewport_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                var diff = e.GetPosition(null) - previousMouse;

                double xSize = myViewport.ActualWidth;
                double ySize = myViewport.ActualHeight;

                const double totalScreen = Math.PI / 2;

                double xRot = diff.X / xSize * totalScreen;
                double yRot = diff.Y / ySize * totalScreen;

                Rotate(xRot, yRot);
            }
        }

        private void Rotate(double leftRightAngle, double upDownAngle) // in radians
        {
            var middle = Center();
            var midpoint = new Point3D(middle.X, middle.Y, middle.Z);
            var axisLR = -Camera.UpDirection;
            var axisUD = Vector3D.CrossProduct(Camera.LookDirection, axisLR);

            var rotationLR = new RotateTransform3D(new AxisAngleRotation3D(axisLR, UtilityFunctions.RadiansToDegrees(leftRightAngle)), midpoint);
            var rotationUD = new RotateTransform3D(new AxisAngleRotation3D(axisUD, UtilityFunctions.RadiansToDegrees(upDownAngle)), midpoint);
            var rotation = new Transform3DGroup() { Children = new Transform3DCollection() { currentTransform, rotationLR, rotationUD } };

            Camera.Transform = rotation;
            Camera.LookDirection = middle - new Vector3D(Camera.Position.X, Camera.Position.Y, Camera.Position.Z);
        }

        private void MyViewport_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            const double factor = 1.1;
            double scale = e.Delta < 0 ? factor : 1 / factor;
            Camera.Position = new Point3D(Camera.Position.X * scale, Camera.Position.Y * scale, Camera.Position.Z * scale);
        }
    }

}
