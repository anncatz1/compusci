﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace VisualizerControl.Shapes
{
    public class CaplessCylinder3D : Shape3D
    {
        static public int NSegments { get; set; } = 16;

        public CaplessCylinder3D() :
            base("Capless cylinder")
        {
        }

        protected override List<Vertex> MakeVertices()
        {
            return CylinderFactory.MakeVertices(false, NSegments);
        }

        protected override Int32Collection MakeTriangles()
        {
            return CylinderFactory.MakeTriangles(false, NSegments);
        }
    }
}
