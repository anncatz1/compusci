﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Interference
{
    static internal class InterferenceDriver
    {
        static public void Run()
        {
            // Create the visualizer
            // Use integers for the number of columns and rows
            // var viz = new InterferenceVisualizer(columns, rows);
            
            // Do your work here

            // Use this to set the color and intensity of a cell
            // Intensity must be between zero and one
            // viz.Display.SetCell(ix, iy, wavelength, intensity);

            // See it!
            // viz.Show();
        }
    }
}
