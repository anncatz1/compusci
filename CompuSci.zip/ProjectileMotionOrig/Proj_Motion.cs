﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities;

namespace ProjectileMotionOrig
{
    class Program
    {
        static void Main(string[] args)
        {
            //LevelI();
            //LevelII();
            //LevelIII();
        }

        //function for level 1 for a ball in free fall, no incorporation of air resistance
        static void LevelI()
        {
            double time = 0;
            double timeInc = 0.01;
            Vector pos = new Vector(0, 0, 0);
            double dist = 0;
            double initialvelmag = 10;
            //Math.PI / 4 is the angle the initial velocity vector is off the ground
            Vector vel = new Vector(initialvelmag * Math.Cos(Math.PI / 4), 0, initialvelmag * Math.Sin(Math.PI / 4));
            double speed = 0;
            Vector accel = new Vector(0, 0, -9.8);
            double magAccel = 0;

            // write data to a text file
            using (StreamWriter writer = File.CreateText(@"c:\Users\student\source\repos\CompuSci\Projectile Motion\Level1.txt"))
            {
                writer.WriteLine("Time (s) \t x \t y \t z \t Distance \t vx \t vy \t vz \t Speed \t ax \t ay \t az \t Acceleration"); //header
                while (pos.Z >= 0)
                {
                    dist = pos.Magnitude;
                    speed = vel.Magnitude;
                    magAccel = accel.Magnitude;
                    writer.WriteLine(time + "\t" + pos.X + "\t" + pos.Y + "\t" + pos.Z + "\t" + dist + "\t" + vel.X + "\t" + vel.Y + "\t" +
                        vel.Z + "\t" + speed + "\t" + accel.X + "\t" + accel.Y + "\t" + accel.Z + "\t" + magAccel);
                    vel = vel + accel * timeInc; //increments velocity based on accel, and pos based on vel
                    pos = pos + vel * timeInc;
                    time += 0.01;
                }
            }
        }

        //function for level 2 for a ball in free fall, with incorporation of air resistance
        static void LevelII()
        {
            double time = 0;
            double timeInc = 0.01;
            Vector pos = new Vector(0, 0, 0);
            double dist = 0;
            double initialvelmag = 10;
            //Math.PI / 4 is the angle the initial velocity vector is off the ground
            Vector vel = new Vector(initialvelmag * Math.Cos(Math.PI / 4), 0, initialvelmag * Math.Sin(Math.PI / 4));
            double speed = 0;
            const double mass = 5;
            Vector forceGravity = new Vector(0, 0, -9.8 * mass); //force of gravity
            const double dragCoef = 0.3;
            Vector forceAir = new Vector(0, 0, 0);
            Vector totalForce = new Vector(0, 0, 0);
            Vector accel = new Vector(0, 0, -9.8);
            double magAccel = 0;

            // write data to a text file
            using (StreamWriter writer = File.CreateText(@"c:\Users\student\source\repos\CompuSci\Projectile Motion\Level2Vectors.txt"))
            {
                writer.WriteLine("Time (s) \t x \t y \t z \t Distance \t vx \t vy \t vz \t Speed \t ax \t ay \t az \t Acceleration"); //header
                while (pos.Z >= 0)
                {
                    forceAir.Z = -dragCoef * vel.Z * speed; //finds force of air resistance
                    totalForce.Z = forceGravity.Z + forceAir.Z; //total force is fAir and fGravity
                    accel.Z = totalForce.Z / mass;
                    dist = pos.Magnitude;
                    speed = vel.Magnitude;
                    magAccel = accel.Magnitude;
                    writer.WriteLine(time + "\t" + pos.X + "\t" + pos.Y + "\t" + pos.Z + "\t" + dist + "\t" + vel.X + "\t" + vel.Y + "\t" +
                        vel.Z + "\t" + speed + "\t" + accel.X + "\t" + accel.Y + "\t" + accel.Z + "\t" + magAccel);
                    vel = vel + accel * timeInc;
                    pos = pos + vel * timeInc;
                    time += 0.01;
                }
            }
        }

        //function for level 3 for a spring with a ball attached to it free fall, incorporation of air resistance
        static void LevelIII()
        {
            double time = 0;
            double timeInc = 0.01;
            Vector pos = new Vector(1, 1, 1);
            double dist = 0;
            Vector vel = new Vector(-2, 1, 3);
            double speed = 0;
            const double mass = 5;
            Vector forceGravity = new Vector(0, 0, -9.8 * mass); //force of gravity
            const double dragCoef = 0.3;
            Vector forceAir = new Vector(0, 0, 0);
            Vector fSpring = new Vector(0, 0, 0);
            Vector totalForce = new Vector(0, 0, 0);
            Vector accel = new Vector(0, 0, -9.8);
            double magAccel = 0;

            // write data to a text file
            using (StreamWriter writer = File.CreateText(@"c:\Users\student\source\repos\CompuSci\Projectile Motion\Level3.txt"))
            {
                writer.WriteLine("Time (s) \t x \t y \t z \t Distance \t vx \t vy \t vz \t Speed \t ax \t ay \t az \t Acceleration"); //header
                while (time < 100)
                {
                    forceAir = new Vector(-dragCoef * vel.X * speed, -dragCoef * vel.Y * speed, -dragCoef * vel.Z * speed); //finds force of air resistance in 3 components
                    fSpring.X = calcSpring(dist, pos.X, pos.X, pos.Y, pos.Z);
                    fSpring.Y = calcSpring(dist, pos.Y, pos.X, pos.Y, pos.Z);
                    fSpring.Z = calcSpring(dist, pos.Z, pos.X, pos.Y, pos.Z);
                    totalForce = forceAir + fSpring + forceGravity; //total force adds up fGravity, fSpring, and fAir 
                    accel = new Vector(totalForce.X / mass, totalForce.Y / mass, totalForce.Z / mass); //used F=ma eq to find a
                    dist = pos.Magnitude;
                    speed = vel.Magnitude;
                    magAccel = accel.Magnitude;
                    writer.WriteLine(time + "\t" + pos.X + "\t" + pos.Y + "\t" + pos.Z + "\t" + dist + "\t" + vel.X + "\t" + vel.Y + "\t" +
                        vel.Z + "\t" + speed + "\t" + accel.X + "\t" + accel.Y + "\t" + accel.Z + "\t" + magAccel);
                    vel = vel + accel * timeInc;
                    pos = pos + vel * timeInc;
                    time += 0.01;
                }
            }
        }

        //calculates force of the spring for each direction component, using directional cosine
        public static double calcSpring(double dist, double wantComponent, double posX, double posY, double posZ)
        {
            double fSpring;
            fSpring = -2 * (dist - 1) * wantComponent / Math.Sqrt(Math.Pow(posX, 2) + Math.Pow(posY, 2) + Math.Pow(posZ, 2));
            return fSpring;
        }
    }
}
