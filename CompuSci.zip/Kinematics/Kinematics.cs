﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Kinematics
{
    class Kinematics
    {
        static void Main(string[] args)
        {
            Level1();
            Level2();
            Level3();
            Challenge();
        }

        static void Level1() {
            //Level 1
            //define variables
            int v = 2;
            Double x = 0;
            Double t = 0;

            // write data to a text file
            using (StreamWriter writer = File.CreateText("c:\\Users\\student\\source\\repos\\CompuSci\\Kinematics\\Level1.txt"))
            {
                writer.WriteLine("Time (s) \t Position (m) \t Velocity (m/s)"); //header
                for (int i = 0; i < 1001; i++)
                {
                    writer.WriteLine(t + "\t" + x + "\t" + v); //prints out data
                    x = x + v * .1; //calculates position 
                    t += 0.1;    //calculates time            
                }
            }
        }

        static void Level2() {
            //Level 2
            Double v2 = 2;
            Double x2 = 0;
            Double t2 = 0;
            Double a = 9.8;

            StreamWriter writer2 = File.CreateText("c:\\Users\\student\\source\\repos\\CompuSci\\Kinematics\\Level2.txt");
            writer2.WriteLine("Time (s) \t Position (m) \t Velocity (m/s) \t Acceleration (m/s^2)");
            for (int i = 0; i < 1001; i++)
            {
                writer2.WriteLine(t2 + "\t" + x2 + "\t" + v2 + "\t" + a);
                v2 = v2 + a * 0.1; //calculates velocity using acceleration
                x2 = x2 + v2 * 0.1; //calculates position using new v
                t2 += 0.1;
            }
            writer2.Close();
        }

        static void Level3() {
            //Level 3
            Double v3 = 2;
            Double x3 = 0;
            Double t3 = 0;
            Double m = 5; //mass
            Double Fg = 9.8 * m; //calculates force of gravity (constant)
            Double air = 0;
            Double a2 = 0;

            // Character stream writing
            StreamWriter writer3 = File.CreateText("c:\\Users\\student\\source\\repos\\CompuSci\\Kinematics\\Level3.txt");
            writer3.WriteLine("Time (s) \t Position (m) \t Velocity (m/s) \t Acceleration (m/s^2)");
            for (int i = 0; i < 1001; i++)
            {
                writer3.WriteLine(t3 + "\t" + x3 + "\t" + v3 + "\t" + a2);
                air = 0.3 * Math.Pow(v3, 2); //calculates Force of air resistance using formula and old v
                a2 = (Fg - air) / m; //calculates acceleartion using Fg and Fair resistance, and f=ma equation
                v3 = v3 + a2 * 0.1; //new v
                x3 = x3 + v3 * 0.1; //new position
                t3 += 0.1;
            }
            writer3.Close();
        }

        static void Challenge() {
            //Challenge
            Double v4 = 2;
            Double x4 = 0;
            Double t4 = 0;
            Double m2 = 5; //mass
            Double Fspring = 0;
            Double Fg2 = 9.8 * m2; //constant gravity
            Double air2 = 0;
            Double a3 = 0;

            // Character stream writing
            StreamWriter writer4 = File.CreateText("c:\\Users\\student\\source\\repos\\CompuSci\\Kinematics\\Level4.txt");
            writer4.WriteLine("Time (s) \t Position (m) \t Velocity (m/s) \t Acceleration (m/s^2)");
            for (int i = 0; i < 1001; i++)
            {
                writer4.WriteLine(t4 + "\t" + x4 + "\t" + v4 + "\t" + a3);
                Fspring = -2 * x4; //calculates force of spring based on position
                air2 = -0.3 * Math.Pow(v4, 2) * Math.Sign(v4); //switches sign of air resistance based on sign of velocity
                a3 = (Fg2 + air2 + Fspring) / m2; //using F=ma equation, calculates acceleration. Ftotal = all forces added together
                v4 = v4 + a3 * 0.1; //new v
                x4 = x4 + v4 * 0.1; //new position
                t4 += 0.1;
            }
            writer4.Close();
        }    
    }
}
