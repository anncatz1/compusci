﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using VisualizerControl.Shapes;
using VisualizerControl.Visualizations;
using Projectile_Motion;
using Utilities;
using System.IO;

namespace Visualizer
{
    static internal class KinematicsDriver
    {
        static Vector3D ConvertToVector3D(Utilities.Vector vector)
        {
            return new Vector3D(vector.X, vector.Y, vector.Z);
        }

        static internal void RunKinematics()
        {
            //Create an engine, for example:
            World engine = new World(10, new Utilities.Vector(0, 0, -9.8));
            
            Utilities.Vector gravity = new Utilities.Vector(0, 0, -9.8);
            const double mass = 5;
            const double drag_coeff = 0.3;
            double initialvelmag = 10;
            Utilities.Vector vel = new Utilities.Vector(initialvelmag * Math.Cos(Math.PI / 4), 0, initialvelmag * Math.Sin(Math.PI / 4));
            Projectile proj = new Projectile(mass, new Utilities.Vector(0, 0, 0), vel, new Utilities.Vector(0, 0, 0), drag_coeff, false, false);
            engine.AddProjectile(proj);

            // Once you have created an adapter class for engine, you can create an instance
            var adapter = new EngineAdapter(engine);

            Sphere3D.NSegments = 40;

            // Create a visualization
            var visualization = new SingleParticleVisualization(adapter);

            // Make a visualizer
            var fullViz = new FullVisualizer(visualization);                     

            // Add graphs
            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.projectiles[0].Pos), "Time (s)", "Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.projectiles[0].Vel), "Time (s)", "Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.projectiles[0].Accel), "Time (s)", "Acceleration (m/s^2)");

            fullViz.Graphs.AddSingleGraph("Speed", () => engine.Time, (() => engine.projectiles[0].Vel.Magnitude),
            Colors.Teal, "Time (s)", "Speed (m/s)");

            // Run it!
            fullViz.Show();
        }

    }
}
